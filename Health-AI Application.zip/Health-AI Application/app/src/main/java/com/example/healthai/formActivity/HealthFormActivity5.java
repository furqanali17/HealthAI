package com.example.healthai.formActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.healthai.R;

public class HealthFormActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_form5);
    }
}