package com.example.healthai.GP;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}